import mysql.connector

conn=mysql.connector.connect(host="localhost",user="root",passwd="@1shwarya")
#print("Opened database successfully")

conn.close()