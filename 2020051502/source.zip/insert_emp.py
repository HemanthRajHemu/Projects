import mysql.connector
def insert_emp():
	#conn=mysql.connector.connect(host="localhost",user="root",passwd="@1shwarya")

	#print("Opened database successfully")
	EID=input("Enter the employee ID: ")
	Ename=input("Enter the employee name: ")
	address=input("Enter the employee address: ")
	qualification=input("Enter the employee qualification: ")
	salary=input("Enter the employee salary: ")
	total_work_days=0
	total_present_days=0
	total_absent_days=0
	

	sql = "INSERT INTO Employee(EID, Ename, address, qualification, salary, total_work_days, total_absent_days, total_present_days) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
	
	val = (EID, Ename, address, qualification, salary, total_work_days, total_present_days, total_absent_days)
	
	mydb = mysql.connector.connect(
                           host="localhost",
                           user="root",
                           passwd="@1shwarya",
                           database="Employee")

	cursor=mydb.cursor()
	cursor.execute(sql, val)

	mydb.commit()
	print(cursor.rowcount, "record inserted.")
	#print("Records created successfully")
	#conn.close()
