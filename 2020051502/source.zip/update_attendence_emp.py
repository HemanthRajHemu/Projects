import mysql.connector
def update_emp_attendence():
	EID=input("Enter the employee ID: ")
	total_work_days=input("Enter the total workdays of employee")
	
	total_absent_days=input("Enter the total absent days of employee")
	total_present_days= int(total_work_days) - int(total_absent_days)

	print("total_present_days")

	sql="UPDATE Employee set total_work_days=%s, total_absent_days=%s, total_present_days=%s WHERE EID=%s"		
	val=(total_work_days, total_absent_days, total_present_days, EID)
	mydb = mysql.connector.connect(
			host="localhost",
                       	user="root",
                        passwd="@1shwarya",
			database="Employee")	
	cursor=mydb.cursor()
	cursor.execute(sql,val)
	mydb.commit()
	print(cursor.rowcount,"record(s) affected")
	return 0;

