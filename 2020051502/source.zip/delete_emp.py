import mysql.connector

def delete_emp():
	#conn=mysql.connector.connect(host="localhost",user="root",passwd="@1shwarya")
	#print("opened database successfully")
	EID=input("Enter the employee ID: ")
	sql="DELETE FROM Employee WHERE EID = %s"
	val=(EID,)
	print("EID", EID)
	mydb = mysql.connector.connect(
                           host="localhost",
                           user="root",
                           passwd="@1shwarya",
                           database="Employee")

	cursor=mydb.cursor()
	cursor.execute(sql, val)
#	cursor=conn.cursor()
#	cursor.execute(query, val)
	mydb.commit()
#	print("the row deleted")
#	conn.close()
#delete_employee()	