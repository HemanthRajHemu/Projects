import mysql.connector
def generate_emp_payslip():
	eid = "none"
	EID=input("Enter Employee ID to generate PaySlip: ")
	sql = "select * from Employee where EID=%s"
	val = (EID,)
	mydb = mysql.connector.connect(
		host="localhost",
		user="root",
		passwd="@1shwarya",
		database="Employee")
	cursor=mydb.cursor()
	cursor.execute(sql, val)
	records=cursor.fetchall()
	for row in records:
		eid = row[0]
		ename = row[1]
		gross_salary = row[4]
		total_work_days = row[5]
		total_present_days = row[6]
		total_absent_days = row[7]
		salary_per_day = (gross_salary/total_work_days)
		net_salary = (salary_per_day * total_present_days)
	if eid == "none":
		print("There is no record associated with this EMPID ", eid)
		return 0;

	print("*********************************************************************************\n")
	print("\t MMEC EMPLOYE PAYROLL MANAGEMENT SYSTEM")

	print("*********************************************************************************\n")
	print("\t EMP ID                :", eid, end = " ")
	print("\t\t EMP NAME            :", ename)
	print("\t No. of Working Days   :", total_work_days, end = " ")
	print("\t\t No.of Present Days  :", total_present_days)
	print("\t No. of Absent Days    :", total_absent_days, end = " ")
	print("\t\t Gross Salary        :", gross_salary)
	print("\t Net in hand salary    : %.2f" % round(net_salary, 2))


	print("*********************************************************************************\n")
