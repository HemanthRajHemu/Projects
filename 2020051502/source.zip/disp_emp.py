import mysql.connector

def display_emp():
	conn=mysql.connector.connect(host="localhost",user="root",passwd="@1shwarya")

	mydb = mysql.connector.connect(
		host="localhost",
		user="root",
		passwd="@1shwarya",
		database="Employee")

	sql_select_query="select *from Employee"
	cursor=mydb.cursor()
	cursor.execute(sql_select_query)
	records=cursor.fetchall()
	print("Total number of rows in Employee is:",cursor.rowcount)
	print("Employee Details")
	print("=====================================================")
	for row in records:
		print("EMP_ID        =",row[0],)
		print("EMP_Name      =",row[1],)
		print("qualification =",row[2],)
		print("address       =",row[3],)
		print("salary        =",row[4])
		print("\n")
	print("=====================================================")






