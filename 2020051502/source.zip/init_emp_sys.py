from insert_emp import *
from generate_payslip import *
from delete_emp import *
from disp_emp import *
from update_attendence_emp import *
from update_emp import *
from connect_db import *
from create_db import *


def get_employee_details():
	display_emp()
	return 0;
def add_new_employee():
	insert_emp()
	return 0;
def delete_employee():
	delete_emp()
	return 0;
def update_employee_details():
	update_emp()
	return 0;
def update_employee_attendence():
	update_emp_attendence()
	return 0;
def generate_employee_pay_slip():
	generate_emp_payslip()
	return 0;

def switch(i):
	switcher={
		'1':get_employee_details,
		'2':add_new_employee,
		'3':delete_employee,
		'4':update_employee_details,
		'5':update_employee_attendence,
		'6':generate_employee_pay_slip,
		}
	func=switcher.get(i,"Invalid Choice")
	return func()

def main_func():
	print("EMPLOYEE PAYROLL MANAGEMENT SYSTEM")
	print("Enter Below Information to Login to system")

	username=input("Enter Username: ")
	password=input("Enter Password: ")
	user="admin"
	passwd="password"
	if username != user:
		print("Invalid Username. Exiting....")
		return 0;
	if password != passwd:
		print("Invalid Password. Exiting...")
		return 0;
	print("Successfully Logged in to the system")

	print("*****************************************************")
	print("MMEC's EMPLOYEE PAYROLL MANAGEMENT SYSTEM")
	print("*****************************************************")

	while 'true':
		print("Welcome to Payroll Management System")
		print("1: GET EMPLOYEE DETAILS")
		print("2: ADD NEW EMPLOYEE")
		print("3: DELETE EMPLOYEE")
		print("4: UPDATE EMPLOYEE DETAILS")
		print("5: UPDATE EMPLOYEE ATTENDENCE")
		print("6: GENERATE EMPLOYEE PAYSLIP")
		choice = input("Enter the Choice: ");
		switch(choice)

main_func()