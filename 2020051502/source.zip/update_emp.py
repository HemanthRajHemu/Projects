import mysql.connector

def update_data(arg1, arg2, col):
	if col == 2:
		sql="UPDATE Employee set Ename=%s WHERE EID=%s"
	elif col == 3:
		sql="UPDATE Employee set qualification=%s WHERE EID=%s"
	elif col == 4:
		sql="UPDATE Employee set address=%s WHERE EID=%s"
	elif col == 5:
		sql="UPDATE Employee set salary=%s WHERE EID=%s"
	elif col == 6:
		sql="UPDATE Employee set total_work_days=%s WHERE EID=%s"
	elif col == 7:
		sql="UPDATE Employee set total_absent_days=%s WHERE EID=%s"
	elif col == 8:
		sql="UPDATE Employee set total_present_days=%s WHERE EID=%s"
		
	else:
		print("Invalid choice\n")
		return

	val=(arg1, arg2)
	mydb = mysql.connector.connect(
                           host="localhost",
                           user="root",
                           passwd="@1shwarya",
                           database="Employee")	
	cursor=mydb.cursor()
	cursor.execute(sql,val)
	mydb.commit()
	print(cursor.rowcount,"record(s) affected")
	return 0;


def get_name():
	eid=input("Enter EID: ")
	name=input("Enter Name to update: ")
	update_data(name, eid, 2)
	return 0;

def get_address():
	eid=input("Enter EID: ")
	address=input("Enter Address to update: ")
	update_data(address, eid, 4)
	return 0;

def get_qualification():
	eid=input("Enter EID: ")
	qual=input("Enter Qualification to update:")
	update_data(qual, eid, 3)
	return 0;

def get_salary():
	eid=input("Enter EID: ")
	salary=input("Enter Salary to update: ")
	update_data(salary, eid, 5)
	return 0;

def get_total_work_days():
	eid=input("Enter EID: ")
	total_work_days=input("Enter total_work_days to update: ")
	update_data(total_work_days, eid, 6)
	return 0;
	
def get_total_absent_days():
	eid=input("Enter EID: ")
	total_absent_days=input("Enter total_absent_days to update: ")
	update_data(total_absent_days, eid, 7)
	return 0;

def get_total_present_days():
	eid=input("Enter EID: ")
	total_work_days=input("Enter total_present_days to update: ")
	update_data(total_present_days, eid, 8)
	return 0;
def switch(i):
	switcher={
		'1':get_name,
		'2':get_qualification,
		'3':get_address,   
		'4':get_salary, 
		'5':get_total_work_days,
		'6':get_total_absent_days,
		'7':get_total_present_days     
        	}
	func=switcher.get(i, 'Invalid Choice')
	return func();

def update_emp():
    print("1: Update Name")
    print("2: Update Qualification")
    print("3: Update Address")
    print("4: Update Salary")
    choice=input("Enter your choice: ")
    print("choice: ", choice)
    switch(choice)

