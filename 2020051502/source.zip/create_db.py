import mysql.connector

conn=mysql.connector.connect(host="localhost",user="root",passwd="@1shwarya")

#print("Opened database successfully")

cursor=conn.cursor();

cursor.execute("CREATE DATABASE IF NOT EXISTS Employee")

cursor.execute("SHOW DATABASES")
#for x in cursor:
#  print(x)
#use database
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="@1shwarya",
  database="Employee"
)

cursor = mydb.cursor()

cursor.execute("CREATE TABLE IF NOT EXISTS Employee (EID INT NOT NULL PRIMARY KEY AUTO_INCREMENT, ENAME VARCHAR(255), ADDRESS VARCHAR(255), QUALIFICATION VARCHAR(50), SALARY INT NOT NULL, TOTAL_WORK_DAYS INT NOT NULL, TOTAL_PRESENT_DAYS INT NOT NULL, TOTAL_ABSENT_DAYS INT NOT NULL)")
cursor.execute("SHOW TABLES")
#for x in cursor:
#  print(x)
#print("Table created successfully")

conn.close()