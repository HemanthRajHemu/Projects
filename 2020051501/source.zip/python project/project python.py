import tkinter as tk
import tkinter.font as tkFont

import sqlite3

window = tk.Tk()
window.title("Online Registration of Financial Aid for Aboard Studies")
window.configure(background='yellow')

window.minsize(1000, 1000) 

ID=tk.StringVar()
Name=tk.StringVar()
Address=tk.StringVar()
Emailaddress=tk.StringVar()
PhoneNo=tk.IntVar()
var=tk.IntVar()
DoB=tk.StringVar()
Age=tk.IntVar()


def database():
    idt=ID.get()
    name=Name.get()
    address=Address.get()
    email=Emailaddress.get()
    phone=PhoneNo.get()
    gender=var.get()
    dob=DoB.get()
    age=Age.get()

    conn = sqlite3.connect('RegistrationForm231445.db')
    with conn:
        cursor=conn.cursor()
        cursor.execute('CREATE TABLE IF NOT EXISTS Student (ID TEXT,Name TEXT,Address TEXT,Emailaddress TEXT,PhoneNo TEXT,Gender TEXT,DoB TEXT,Age TEXT)')
        cursor.execute('INSERT INTO Student (ID,Name,Address,Emailaddress,PhoneNo,Gender,DoB,Age) VALUES(?,?,?,?,?,?,?,?)',(idt,name,address,email,phone,gender,dob,age,))
        conn.commit()


fontStyle = tkFont.Font(family="Lucida Grande", size=20)

l2=tk.Label(window, text="Online Registration of Financial Aid for Aboard Studies Form", font=fontStyle)
l2.pack()

label = tk.Label(text="ID:")
label.pack()


entry = tk.Entry(window,textvar=ID)
entry.pack()


label = tk.Label(text="Name:")
label.pack()


entry = tk.Entry(window,textvar=Name)
entry.pack()

label = tk.Label(text="Address:")
label.pack()


entry = tk.Entry(window,textvar=Address)
entry.pack()

label = tk.Label(text="Emailaddress:")
label.pack()


entry = tk.Entry(window,textvar=Emailaddress)
entry.pack()

label = tk.Label(text="PhoneNo:")
label.pack()


entry = tk.Entry(window,textvar=PhoneNo)
entry.pack()

label = tk.Label(text="Gender:")
label.pack()

var = tk.StringVar(window, "Male")
R4 = tk.Radiobutton(window, text="Male", variable=var, value="Male")
R4.pack()

R5 = tk.Radiobutton(window, text="Female", variable=var, value="Female")
R5.pack()

label = tk.Label(text="DoB:")
label.pack()


entry = tk.Entry(window,textvar=DoB)
entry.pack()



label = tk.Label(text="Age:")
label.pack()


entry = tk.Entry(window,textvar=Age)
entry.pack()



B = tk.Button(window, text ="Submit", command = database,bg="blue")
B.pack()


window.mainloop()
