import tkinter as tk

window = tk.Tk()
window.title("GUI")

window.configure(background='yellow')

window.minsize(500,500)



label = tk.Label(text="Online Finanical Aid  form  For the Aboard Studies ")
label.pack()


def displaySubmit():
      name = entry.get()
      

      l2.configure(text="Welcome "+name)
      print("You have registered ")


label = tk.Label(text="First Name:")
label.pack()


entry = tk.Entry()
entry.pack()


label = tk.Label(text="Middle Intial:")
label.pack()

entry = tk.Entry()
entry.pack()



label = tk.Label(text="Last Name:")
label.pack()

entry = tk.Entry()
entry.pack()




label = tk.Label(text=" Permanent Address:")
label.pack()


entry = tk.Entry()
entry.pack()

entry = tk.Entry()
entry.pack()



label = tk.Label(text="Please  select the gender:")
label.pack()

var = tk.StringVar(window, "Male")
R4 = tk.Radiobutton(window, text="Male", variable=var, value="Male")
R4.pack()

R5 = tk.Radiobutton(window, text="Female", variable=var, value="Female")
R5.pack()



label = tk.Label(text="City:")
label.pack()


entry = tk.Entry()
entry.pack()



label = tk.Label(text="State:")
label.pack()


entry = tk.Entry()
entry.pack()



label = tk.Label(text="Postal code:")
label.pack()


entry = tk.Entry()
entry.pack()



label = tk.Label(text="Your date of birth:")
label.pack()


entry = tk.Entry()
entry.pack()



label = tk.Label(text="Phone No:")
label.pack()

entry = tk.Entry()
entry.pack()



label = tk.Label(text="Telphone No:")
label.pack()

entry = tk.Entry()
entry.pack()




label = tk.Label(text="Adhar ID or Driver License:")
label.pack()


entry = tk.Entry()
entry.pack()




label = tk.Label(text="Email Address:}")
label.pack()

entry = tk.Entry()
entry.pack()




B = tk.Button(window, text ="Submit", command = displaySubmit)

B.pack()

l2 = tk.Label(text="Sign up")
l2.pack()





window.mainloop()
