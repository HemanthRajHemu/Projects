from create_db import *
from create_acc import *
from create_pin import *
from deposit import *
from withdraw import *
from view_bal import *




def switch(i):
	switcher={
		'1':create_account,
		'2':view_balance,
		'3':withdraw_money,
		'4':deposit_money,
		'5':create_pin,
		} 
	func=switcher.get(i,"INVALID CHOICE")
	return func()

def main_func():
	
	print("********************************")
	print("BANK ATM VENDER SYSTEM")
	print("********************************")

	while 'true':
		print("Welcome to BANK ATM VENDER SYSTEM")
		print("1:CREATE ACCOUNT")
		print("2:VIEW BALANCE")
		print("3:WITHDRAW MONEY")
		print("4:DEPOSIT MONEY")
		print("5:CREATE PIN")
		choice=input("Enter the choice: ");
		switch(choice)
main_func()

