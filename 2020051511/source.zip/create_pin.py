import mysql.connector

def create_pin():
	cust_ID=input("Enter customer ID to generate pin: ")
	phone_no=input("Enter the phone number: ")
	sql="select * from customer where cust_ID=%s"
	val=(cust_ID,)
	mydb=mysql.connector.connect(host="localhost", user="root", passwd="@1shwarya", database="atm")
	cursor=mydb.cursor()
	cursor.execute(sql,val)
	records = cursor.fetchall()
	print("count", cursor.rowcount)
	for row in records:
		cid = row[0]
		pno = row[3]

	print("cid", cid)
	print("cid", cust_ID)
	print("pno", pno)
	if str(cid) == str(cust_ID):
		if pno == phone_no:
			pin_no = input("Enter new pin: ")
			sql = "update customer set pin_no=%s where cust_id=%s"
			val = (pin_no, cust_ID)
			cursor=mydb.cursor()
			cursor.execute(sql,val)
			mydb.commit()
		else:
			print("phone is not correct")
	else:
		print("customer id is not correct")
