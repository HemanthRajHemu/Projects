import mysql.connector
def deposit_money():
	cust_ID=input("Enter the customer ID")
	acc_no=input("Enter pin number: ")
	deposit_amount=input("Enter the amount: ")

	sql="select * from customer where cust_ID=%s"
	val=(cust_ID,)
	mydb=mysql.connector.connect(
			host="localhost",
			user="root",
			passwd="@1shwarya",
			database="ATM")
	cursor=mydb.cursor()
	cursor.execute(sql,val)
	records = cursor.fetchall()
	for row in records:
		balance = row[4]

	balance=int(balance)+int(deposit_amount)
	print("Amount deposited is", deposit_amount)
	print("Total Balance is", balance)
	sql="update customer set balance=%s where cust_ID=%s"
	val=(balance, cust_ID)
	cursor.execute(sql,val)
	mydb.commit()
