import mysql.connector

def create_account():

	cust_ID=input("Enter the customer ID: ")
	cust_name=input("Enter the customer name: ")
	acc_no=input("Enter the account number: ")
	phone_no=input("Enter your phone number: ")
	deposit_money=input("Enter the deposit amount: ")
	pin_no=0

	sql = "INSERT INTO CUSTOMER(cust_ID, cust_name, acc_no, phone_no, balance, pin_no) VALUES (%s, %s, %s, %s, %s, %s)"
	val = (cust_ID, cust_name, acc_no, phone_no, deposit_money, pin_no)

	mydb=mysql.connector.connect(
		host="localhost",
		user="root",
		passwd="@1shwarya",
		database="ATM")

	cursor=mydb.cursor()

	cursor.execute(sql,val)
	mydb.commit()
	print(cursor.rowcount, "record inserted.")
