import mysql.connector
def view_balance():
	cust_ID=input("Enter the customer ID: ")
	pin_no=input("Enter the pin number: ")
	sql="select * from customer where cust_ID=%s"
	val=(cust_ID,)
	mydb=mysql.connector.connect(
			host="localhost",
			user="root",
			passwd="@1shwarya",
			database="ATM")
	cursor=mydb.cursor()
	cursor.execute(sql,val)
	records = cursor.fetchall()
	for row in records:
		balance = row[4]
		pin=row[5]
	if str(pin) == str(pin_no):
		print("Available balance is: ", balance);
	else:
		print("Incorrect pin entered")
	mydb.commit()
 