#!/usr/bin/env python
# coding: utf-8

# In[7]:


from tkinter import *
import time
import datetime
import random

root =Tk()
root.geometry("1350x700")
root.title("Restaurant Billing System")
root.configure(background='black')

Tops = Frame(root,bg='red',bd=20,pady=5,relief=RIDGE)
Tops.pack(side=TOP)

lblTitle=Label(Tops,font=('arial',60,'bold'),text='Restaurant Billing System',bd=21,bg='orange',fg='black',justify=CENTER)
lblTitle.grid(row=0)


ReceiptCal_F = Frame(root,bg='orange',height=300,bd=10,relief=RIDGE)
ReceiptCal_F.pack(side=RIGHT)

Buttons_F=Frame(ReceiptCal_F,bg='orange',bd=7,relief=RIDGE)
Buttons_F.pack(side=BOTTOM)


Receipt_F=Frame(ReceiptCal_F,bg='orange',bd=3,relief=RIDGE)
Receipt_F.pack(side=BOTTOM)

MenuFrame = Frame(root,bg='orange',bd=10,relief=RIDGE)
MenuFrame.pack(side=LEFT)
Cost_F=Frame(MenuFrame,bg='orange',bd=4)
Cost_F.pack(side=BOTTOM)
Drinks_F=Frame(MenuFrame,bg='orange',bd=4)
Drinks_F.pack(side=TOP)


Drinks_F=Frame(MenuFrame,bg='orange',bd=4,relief=RIDGE)
Drinks_F.pack(side=LEFT)
Food_F=Frame(MenuFrame,bg='orange',bd=4,relief=RIDGE)
Food_F.pack(side=RIGHT)

var1=IntVar()
var2=IntVar()
var3=IntVar()
var4=IntVar()
var5=IntVar()
var6=IntVar()
var7=IntVar()
var8=IntVar()
var9=IntVar()
var10=IntVar()
var11=IntVar()
var12=IntVar()
var13=IntVar()
var14=IntVar()
var15=IntVar()
var16=IntVar()

DateofOrder = StringVar()
Receipt_Ref = StringVar()
PaidTax = StringVar()
SubTotal = StringVar()
TotalCost = StringVar()
CostofFood = StringVar()
CostofDrinks = StringVar()
ServiceCharge = StringVar()

text_Input = StringVar()
operator = ""

E_sup = StringVar()
E_sprite = StringVar()
E_Coke = StringVar()
E_Mojito = StringVar()
E_Cappuccino = StringVar()
E_tea = StringVar()
E_coffee = StringVar()
E_ColdCoffee = StringVar()

E_soup = StringVar()
E_dosa = StringVar()
E_Pasta = StringVar()
E_Burger = StringVar()
E_pizza = StringVar()
E_Fires = StringVar()
E_meal = StringVar()
E_sandwich = StringVar()

E_sup.set("0")
E_sprite.set("0")
E_Coke.set("0")
E_Mojito.set("0")
E_Cappuccino.set("0")
E_tea.set("0")
E_coffee.set("0")
E_ColdCoffee.set("0")

E_soup.set("0")
E_dosa.set("0")
E_Pasta.set("0")
E_Burger.set("0")
E_pizza.set("0")
E_Fires.set("0")
E_meal.set("0")
E_sandwich.set("0")

DateofOrder.set(time.strftime("%d/%m/%y"))


def iExit():
        root.destroy()
        return

def Reset():

    PaidTax.set("")
    SubTotal.set("")
    TotalCost.set("")
    CostofFood.set("")
    CostofDrinks.set("")
    ServiceCharge.set("")
    txtReceipt.delete("1.0",END)

    E_sup.set("0")
    E_sprite.set("0")
    E_Coke.set("0")
    E_Mojito.set("0")
    E_Cappuccino.set("0")
    E_tea.set("0")
    E_coffee.set("0")
    E_ColdCoffee.set("0")

    E_soup.set("0")
    E_dosa.set("0")
    E_Pasta.set("0")
    E_Burger.set("0")
    E_pizza.set("0")
    E_Fires.set("0")
    E_meal.set("0")
    E_sandwich.set("0")

    var1.set(0)
    var2.set(0)
    var3.set(0)
    var4.set(0)
    var5.set(0)
    var6.set(0)
    var7.set(0)
    var8.set(0)
    var9.set(0)
    var10.set(0)
    var11.set(0)
    var12.set(0)
    var13.set(0)
    var14.set(0)
    var15.set(0)
    var16.set(0)


    txtsup.configure(state=DISABLED)
    txtsprite.configure(state=DISABLED)
    txtCoke.configure(state=DISABLED)
    txtMojito.configure(state=DISABLED)
    txtCappuccino.configure(state=DISABLED)
    txttea.configure(state=DISABLED)
    txtcoffee.configure(state=DISABLED)
    txtColdCoffee.configure(state=DISABLED)
    txtsoup.configure(state=DISABLED)
    txtdosa.configure(state=DISABLED)
    txtPasta.configure(state=DISABLED)
    txtBurger.configure(state=DISABLED)
    txtpizza.configure(state=DISABLED)
    txtFires.configure(state=DISABLED)
    txtmeal.configure(state=DISABLED)
    txtsandwich.configure(state=DISABLED)

def CostofItem():
    I1=float(E_sup.get())
    I2=float(E_sprite.get())
    I3=float(E_Coke.get())
    I4=float(E_Mojito.get())
    I5=float(E_Cappuccino.get())
    I6=float(E_tea.get())
    I7=float(E_coffee.get())
    I8=float(E_ColdCoffee.get())
    
    I9=float(E_soup.get())
    I10=float(E_dosa.get())
    I11=float(E_Pasta.get())
    I12=float(E_Burger.get())
    I13=float(E_pizza.get())
    I14=float(E_Fires.get())
    I15=float(E_meal.get())
    I16=float(E_sandwich.get())

    PriceofDrinks =(I1 * 65) + (I2 * 65) + (I3 * 70) + (I4 * 120) + (I5 * 150) + (I6 * 50) + (I7 * 50) + (I8 * 90)

    PriceofFood =(I9 * 120) + (I10 * 125) + (I11 * 135) + (I12 * 180) + (I13 * 220) + (I14 * 130) + (I15 * 250) + (I16 * 130)



    DrinksPrice = "Rs",str('%.2f'%(PriceofDrinks))
    FoodPrice =  "Rs",str('%.2f'%(PriceofFood))
    CostofFood.set(FoodPrice)
    CostofDrinks.set(DrinksPrice)
    SC = "Rs",str('%.2f'%(1.59))
    ServiceCharge.set(SC)

    SubTotalofITEMS = "Rs",str('%.2f'%(PriceofDrinks + PriceofFood + 1.59))
    SubTotal.set(SubTotalofITEMS)

    Tax = "Rs",str('%.2f'%((PriceofDrinks + PriceofFood + 1.59) * 0.15))
    PaidTax.set(Tax)

    TT=((PriceofDrinks + PriceofFood + 1.59) * 0.15)
    TC="Rs",str('%.2f'%(PriceofDrinks + PriceofFood + 1.59 + TT))
    TotalCost.set(TC)


def chksup():
    if(var1.get() == 1):
        txtsup.configure(state = NORMAL)
        txtsup.focus()
        txtsup.delete('0',END)
        E_sup.set("")
    elif(var1.get() == 0):
        txtsup.configure(state = DISABLED)
        E_sup.set("0")

def chksprite():
    if(var2.get() == 1):
        txtsprite.configure(state = NORMAL)
        txtsprite.focus()
        txtsprite.delete('0',END)
        E_sprite.set("")
    elif(var2.get() == 0):
        txtsprite.configure(state = DISABLED)
        E_sprite.set("0")

def chk_Coke():
    if(var3.get() == 1):
        txtCoke.configure(state = NORMAL)
        txtCoke.delete('0',END)
        txtCoke.focus()
    elif(var3.get() == 0):
        txtCoke.configure(state = DISABLED)
        E_Coke.set("0")

def chk_Mojito():
    if(var4.get() == 1):
        txtMojito.configure(state = NORMAL)
        txtMojito.delete('0',END)
        txtMojito.focus()
    elif(var4.get() == 0):
        txtMojito.configure(state = DISABLED)
        E_Mojito.set("0")

def chk_Cappuccino():
    if(var5.get() == 1):
        txtCappuccino.configure(state = NORMAL)
        txtCappuccino.delete('0',END)
        txtCappuccino.focus()
    elif(var5.get() == 0):
        txtCappuccino.configure(state = DISABLED)
        E_Cappuccino.set("0")

def chk_tea():
    if(var6.get() == 1):
        txttea.configure(state = NORMAL)
        txttea.delete('0',END)
        txttea.focus()
    elif(var6.get() == 0):
        txttea.configure(state = DISABLED)
        E_tea.set("0")

def chk_coffee():
    if(var7.get() == 1):
        txtcoffee.configure(state = NORMAL)
        txtcoffee.delete('0',END)
        txtcoffee.focus()
    elif(var7.get() == 0):
        txtcoffee.configure(state = DISABLED)
        E_coffee.set("0")

def chk_ColdCoffee():
    if(var8.get() == 1):
        txtColdCoffee.configure(state = NORMAL)
        txtColdCoffee.delete('0',END)
        txtColdCoffee.focus()
    elif(var8.get() == 0):
        txtColdCoffee.configure(state = DISABLED)
        E_ColdCoffee.set("0")

def chk_soup():
    if(var9.get() == 1):
        txtsoup.configure(state = NORMAL)
        txtsoup.delete('0',END)
        txtsoup.focus()
    elif(var9.get() == 0):
        txtsoup.configure(state = DISABLED)
        E_soup.set("0")

def chk_dosa():
    if(var10.get() == 1):
        txtdosa.configure(state = NORMAL)
        txtdosa.delete('0',END)
        txtdosa.focus()
    elif(var10.get() == 0):
        txtdosa.configure(state = DISABLED)
        E_dosa.set("0")

def chk_Pasta():
    if(var11.get() == 1):
        txtPasta.configure(state = NORMAL)
        txtPasta.delete('0',END)
        txtPasta.focus()
    elif(var11.get() == 0):
        txtPasta.configure(state = DISABLED)
        E_Pasta.set("0")

def chk_Burger():
    if(var12.get() == 1):
        txtBurger.configure(state = NORMAL)
        txtBurger.delete('0',END)
        txtBurger.focus()
    elif(var12.get() == 0):
        txtBurger.configure(state = DISABLED)
        E_Burger.set("0")

def chk_pizza():
    if(var13.get() == 1):
        txtpizza.configure(state = NORMAL)
        txtpizza.delete('0',END)
        txtpizza.focus()
    elif(var13.get() == 0):
        txtpizza.configure(state = DISABLED)
        E_pizza.set("0")

def chk_Fires():
    if(var14.get() == 1):
        txtFires.configure(state = NORMAL)
        txtFires.delete('0',END)
        txtFires.focus()
    elif(var14.get() == 0):
        txtFires.configure(state = DISABLED)
        E_Fires.set("0")

def chk_meal():
    if(var15.get() == 1):
        txtmeal.configure(state = NORMAL)
        txtmeal.delete('0',END)
        txtmeal.focus()
    elif(var15.get() == 0):
        txtmeal.configure(state = DISABLED)
        E_meal.set("0")

def chk_sandwich():
    if(var16.get() == 1):
        txtsandwich.configure(state = NORMAL)
        txtsandwich.delete('0',END)
        txtsandwich.focus()
    elif(var16.get() == 0):
        txtsandwich.configure(state = DISABLED)
        E_sandwich.set("0")

def Receipt():
    txtReceipt.delete("1.0",END)
    x=random.randint(10908,500876)
    randomRef= str(x)
    Receipt_Ref.set("Bill"+ randomRef)


    txtReceipt.insert(END,'Receipt Ref:\t\t\t    '+Receipt_Ref.get() +'\t'+ DateofOrder.get() +'\n')
    txtReceipt.insert(END,'Items\t\t\t   '+"Cost of Items \n")
    txtReceipt.insert(END,'7 Up:\t\t\t\t' + E_sup.get() +'\n')
    txtReceipt.insert(END,'Sprite:\t\t\t\t'+ E_sprite.get()+'\n')
    txtReceipt.insert(END,'Coke:\t\t\t\t'+ E_Coke.get()+'\n')
    txtReceipt.insert(END,'Mojito:\t\t\t\t'+ E_Mojito.get()+'\n')
    txtReceipt.insert(END,'Cappuccino:\t\t\t\t'+ E_Cappuccino.get()+'\n')
    txtReceipt.insert(END,'Tea:\t\t\t\t'+ E_tea.get()+'\n')
    txtReceipt.insert(END,'Coffee:\t\t\t\t'+ E_coffee.get()+'\n')
    txtReceipt.insert(END,'ColdCoffee:\t\t\t\t'+ E_ColdCoffee.get()+'\n')
    txtReceipt.insert(END,'Soup:\t\t\t\t'+ E_soup.get()+'\n')
    txtReceipt.insert(END,'Dosa:\t\t\t\t'+ E_dosa.get()+'\n')
    txtReceipt.insert(END,'Pasta:\t\t\t\t'+ E_Pasta.get()+'\n')
    txtReceipt.insert(END,'Burger:\t\t\t\t'+ E_Burger.get()+'\n')
    txtReceipt.insert(END,'Pizza:\t\t\t\t'+ E_pizza.get()+'\n')
    txtReceipt.insert(END,'Fires:\t\t\t\t'+ E_Fires.get()+'\n')
    txtReceipt.insert(END,'Meal:\t\t\t\t'+ E_meal.get()+'\n')
    txtReceipt.insert(END,'Sandwich:\t\t\t\t'+ E_sandwich.get()+'\n')
    txtReceipt.insert(END,'Cost of Drinks:\t\t\t'+ CostofDrinks.get()+'\nTax Paid:\t\t\t'+PaidTax.get()+"\n")
    txtReceipt.insert(END,'Cost of Foods:\t\t\t'+ CostofFood.get()+'\nSubTotal:\t\t\t'+str(SubTotal.get())+"\n")
    txtReceipt.insert(END,'Service Charge:\t\t\t'+ ServiceCharge.get()+'\nTotal Cost:\t\t\t'+str(TotalCost.get())+"\n")


sup=Checkbutton(Drinks_F,text='7 Up\t',variable=var1,onvalue=1,offvalue=0,font=('arial',18,'bold'),
                    bg='orange',command=chksup).grid(row=0,sticky=W)
sprite=Checkbutton(Drinks_F,text='Sprite',variable=var2,onvalue=1,offvalue=0,font=('arial',18,'bold'),
                    bg='orange',command=chksprite).grid(row=1,sticky=W)
Coke=Checkbutton(Drinks_F,text='Coke',variable=var3,onvalue=1,offvalue=0,font=('arial',18,'bold'),
                    bg='orange',command=chk_Coke).grid(row=2,sticky=W)
Mojito=Checkbutton(Drinks_F,text='Mojito',variable=var4,onvalue=1,offvalue=0,font=('arial',18,'bold'),
                    bg='orange',command=chk_Mojito).grid(row=3,sticky=W)
Cappuccino=Checkbutton(Drinks_F,text='Cappuccino',variable=var5,onvalue=1,offvalue=0,font=('arial',18,'bold'),
                    bg='orange',command=chk_Cappuccino).grid(row=4,sticky=W)
tea=Checkbutton(Drinks_F,text='Tea',variable=var6,onvalue=1,offvalue=0,font=('arial',18,'bold'),
                    bg='orange',command=chk_tea).grid(row=5,sticky=W)
coffee=Checkbutton(Drinks_F,text='Coffee',variable=var7,onvalue=1,offvalue=0,font=('arial',18,'bold'),
                    bg='orange',command=chk_coffee).grid(row=6,sticky=W)
ColdCoffee=Checkbutton(Drinks_F,text='ColdCoffee',variable=var8,onvalue=1,offvalue=0,font=('arial',18,'bold'),
                    bg='orange',command=chk_ColdCoffee).grid(row=7,sticky=W)


txtsup = Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
                        ,textvariable=E_sup)
txtsup.grid(row=0,column=2)

txtsprite = Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
                        ,textvariable=E_sprite)
txtsprite.grid(row=1,column=2)

txtCoke = Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
                        ,textvariable=E_Coke)
txtCoke.grid(row=2,column=2)

txtMojito= Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
                        ,textvariable=E_Mojito)
txtMojito.grid(row=3,column=2)

txtCappuccino = Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
                        ,textvariable=E_Cappuccino)
txtCappuccino.grid(row=4,column=2)

txttea = Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
                        ,textvariable=E_tea)
txttea.grid(row=5,column=2)

txtcoffee = Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
                        ,textvariable=E_coffee)
txtcoffee.grid(row=6,column=2)

txtColdCoffee = Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
                        ,textvariable=E_ColdCoffee)
txtColdCoffee.grid(row=7,column=2)


soup = Checkbutton(Food_F,text="Soup\t\t\t ",variable=var9,onvalue = 1, offvalue=0,
                        font=('arial',16,'bold'),bg='orange',command=chk_soup).grid(row=0,sticky=W)
dosa = Checkbutton(Food_F,text="Dosa\t\t\t",variable=var10,onvalue = 1, offvalue=0,
                        font=('arial',16,'bold'),bg='orange',command=chk_dosa).grid(row=1,sticky=W)
Pasta = Checkbutton(Food_F,text="Pasta ",variable=var11,onvalue = 1, offvalue=0,
                        font=('arial',16,'bold'),bg='orange',command=chk_Pasta).grid(row=2,sticky=W)
Burger = Checkbutton(Food_F,text="Burger ",variable=var12,onvalue = 1, offvalue=0,
                        font=('arial',16,'bold'),bg='orange',command=chk_Burger).grid(row=3,sticky=W)
pizza = Checkbutton(Food_F,text="Pizza ",variable=var13,onvalue = 1, offvalue=0,
                        font=('arial',16,'bold'),bg='orange',command=chk_pizza).grid(row=4,sticky=W)
Fires = Checkbutton(Food_F,text="Fires ",variable=var14,onvalue = 1, offvalue=0,
                        font=('arial',16,'bold'),bg='orange',command=chk_Fires).grid(row=5,sticky=W)
meal = Checkbutton(Food_F,text="Meal ",variable=var15,onvalue = 1, offvalue=0,
                        font=('arial',16,'bold'),bg='orange',command=chk_meal).grid(row=6,sticky=W)
sandwich = Checkbutton(Food_F,text="Sandwich ",variable=var16,onvalue = 1, offvalue=0,
                        font=('arial',16,'bold'),bg='orange',command=chk_sandwich).grid(row=7,sticky=W)


txtsoup=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
                        textvariable=E_soup)
txtsoup.grid(row=0,column=1)

txtdosa=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
                        textvariable=E_dosa)
txtdosa.grid(row=1,column=1)

txtPasta=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
                        textvariable=E_Pasta)
txtPasta.grid(row=2,column=1)

txtBurger=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
                      textvariable=E_Burger)
txtBurger.grid(row=3,column=1)

txtpizza=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
                        textvariable=E_pizza)
txtpizza.grid(row=4,column=1)

txtFires=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
                        textvariable=E_Fires)
txtFires.grid(row=5,column=1)

txtmeal=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
                        textvariable=E_meal)
txtmeal.grid(row=6,column=1)

txtsandwich=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
                        textvariable=E_sandwich)
txtsandwich.grid(row=7,column=1)


lblCostofDrinks=Label(Cost_F,font=('arial',14,'bold'),text='Cost of Drinks',bg='orange',
                fg='black',justify=CENTER)
lblCostofDrinks.grid(row=0,column=0,sticky=W)
txtCostofDrinks=Entry(Cost_F,bg='white',bd=7,font=('arial',14,'bold'),
                        insertwidth=2,justify=RIGHT,textvariable=CostofDrinks)
txtCostofDrinks.grid(row=0,column=1)

lblCostofFood=Label(Cost_F,font=('arial',14,'bold'),text='Cost of Foods  ',bg='orange',
                fg='black',justify=CENTER)
lblCostofFood.grid(row=1,column=0,sticky=W)
txtCostofFood=Entry(Cost_F,bg='white',bd=7,font=('arial',14,'bold'),
                        insertwidth=2,justify=RIGHT,textvariable=CostofFood)
txtCostofFood.grid(row=1,column=1)

lblServiceCharge=Label(Cost_F,font=('arial',14,'bold'),text='Service Charge',bg='orange',
                fg='black',justify=CENTER)
lblServiceCharge.grid(row=2,column=0,sticky=W)
txtServiceCharge=Entry(Cost_F,bg='white',bd=7,font=('arial',14,'bold'),
                        insertwidth=2,justify=RIGHT,textvariable=ServiceCharge)
txtServiceCharge.grid(row=2,column=1)


lblPaidTax=Label(Cost_F,font=('arial',14,'bold'),text='\tPaid Tax',bg='orange',bd=7,
                fg='black',justify=CENTER)
lblPaidTax.grid(row=0,column=2,sticky=W)
txtPaidTax=Entry(Cost_F,bg='white',bd=7,font=('arial',14,'bold'),
                        insertwidth=2,justify=RIGHT,textvariable=PaidTax)
txtPaidTax.grid(row=0,column=3)

lblSubTotal=Label(Cost_F,font=('arial',14,'bold'),text='\tSub Total',bg='orange',bd=7,
                fg='black',justify=CENTER)
lblSubTotal.grid(row=1,column=2,sticky=W)
txtSubTotal=Entry(Cost_F,bg='white',bd=7,font=('arial',14,'bold'),
                        insertwidth=2,justify=RIGHT,textvariable=SubTotal)
txtSubTotal.grid(row=1,column=3)

lblTotalCost=Label(Cost_F,font=('arial',14,'bold'),text='\tTotal',bg='orange',bd=7,
                fg='black',justify=CENTER)
lblTotalCost.grid(row=2,column=2,sticky=W)
txtTotalCost=Entry(Cost_F,bg='white',bd=7,font=('arial',14,'bold'),
                        insertwidth=2,justify=RIGHT,textvariable=TotalCost)
txtTotalCost.grid(row=2,column=3)



txtReceipt=Text(Receipt_F,width=50,height=24,bg='white',bd=4,font=('arial',12,'bold'))
txtReceipt.grid(row=0,column=0)



btnTotal=Button(Buttons_F,padx=16,pady=1,bd=7,fg='black',font=('arial',16,'bold'),width=4,text='Total',
                        bg='orange',command=CostofItem).grid(row=0,column=0)
btnReceipt=Button(Buttons_F,padx=16,pady=1,bd=7,fg='black',font=('arial',16,'bold'),width=4,text='Receipt',
                        bg='orange',command=Receipt).grid(row=0,column=1)
btnReset=Button(Buttons_F,padx=16,pady=1,bd=7,fg='black',font=('arial',16,'bold'),width=4,text='Reset',
                        bg='orange',command=Reset).grid(row=0,column=2)
btnExit=Button(Buttons_F,padx=16,pady=1,bd=7,fg='black',font=('arial',16,'bold'),width=4,text='Exit',
                        bg='orange',command=iExit).grid(row=0,column=3)



root.mainloop()

