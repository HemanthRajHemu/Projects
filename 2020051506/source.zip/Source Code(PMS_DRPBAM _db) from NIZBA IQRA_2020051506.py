import sqlite3
#it connects to the database
def connectDatabase():
    global conn
    conn=sqlite3.connect('DRPBAM.db')
    print("opened database successfully")

#This would create a table
def CreateTable():

#DOCTOR DETAILS
    conn.execute('''CREATE TABLE IF NOT EXISTS DDETAILS
        (ID INT[20],
        DNAME CHAR(50) NOT NULL,
        ADDRESS CHAR(50),
        PHONE CHAR(15) NOT NULL,
        QUALIFICATION CHAR(20) NOT NULL,
        GENDER CHAR(10) NOT NULL);''')
#ROOM DETAILS
    conn.execute('''CREATE TABLE IF NOT EXISTS RDETAILS
        (PATIENTID INTEGER PRIMARY KEY AUTOINCREMENT,
        PATIENTNAME CHAR[50],
        ROOMID INT[20],
        ROOMTYPE CHAR(50) NOT NULL);''')#ROOMTYPE MEANS:GENERAL/PRIVATE
#PATIENT DETAILS
    conn.execute('''CREATE TABLE IF NOT EXISTS PDETAILS
        (PATIENTID INTEGER PRIMARY KEY AUTOINCREMENT,
        PATIENTNAME CHAR(50) NOT NULL,
        AGE INT(10),
        GENDER CHAR(50),
        ADDRESS CHAR(50),
        DATE OF ADMISSION INT(20),
        CONTACT NUMBER CHAR(15) NOT NULL);''')
#BILL DETAILS
    conn.execute('''CREATE TABLE IF NOT EXISTS BDETAILS
        (BILLNO INT[20],
        GENERATED BILLDATE INT(20) NOT NULL,
        PATIENTID INTEGER PRIMARY KEY AUTOINCREMENT,
        PNAME CHAR(50) NOT NULL,
        AGE INT(10),
        ADMISSIONDATE INT(20),
        DISCHARGEDATE INT(20),
        ROOM CHARGES INT(20),
        PATHOLOGY FEES INT(50) NOT NULL,
        DOCTOR CHECKUP FEE INT(50)NOT NULL,
        MISCELLANEOUS FEE INT(50) NOT NULL,
        TOTAL AMOUNT OF BILL INT(80) NOT NULL);''')
#appointment details
    conn.execute('''CREATE TABLE IF NOT EXISTS ADETAILS
        (PATIENTID INTEGER PRIMARY KEY AUTOINCREMENT,
        PATIENTNAME VARCHAR[50],
        DOCTORNAME VARCHAR[50],
        CONSULTFEES VARCHAR[50],
        APPOINTMENTDATE INT[50],
        APPOINTMENTTIME INT[50],
        TIMEPREFERRED INT[20],
        APPOINTMENT NUMBER INT[20],
        PAYMENTMODE CHAR[50]);''')
#MEDICINE DETAILS
    conn.execute('''CREATE TABLE IF NOT EXISTS MDETAILS
        (PATIENTID INTEGER PRIMARY KEY AUTOINCREMENT,
        PATIENTNAME VARCHAR[50],
        DISEASEOFPATIENT VARCHAR[50],
        MEDICINERECOMMENDED VARCHAR[50],
        CONSULTEDDOCTORNAME VARCHAR[50]);''')

    print("table created successfully")

#this will close a connection to Database 
def CloseDatabase():
    conn.close()

#this would insert a new record to database
def NewRecord():
#DDETAILS
    print("\n Doctor Details:")
    id=int(input("enter doctor's id:"))
    dname=input("enter the doctor's name:")
    address=input("enter the address:")
    phone=input("enter the phone number:")
    qualification=input("enter the qualification:")
    gender=input("enter gender:")
    conn.execute("INSERT INTO DDETAILS(ID,DNAME,ADDRESS,PHONE,QUALIFICATION,GENDER)VALUES(?,?,?,?,?,?)",(id,dname,address,phone,qualification,gender));

#RDETAILS
    print("\n Room Details:")
    patientid=int(input("enter patientid:"))
    patientname=input("enter patient name:") 
    roomid=int(input(" enter roomid number"))
    roomtype=input("enter roomtype[general/private]")
    conn.execute("INSERT INTO RDETAILS\
        (PATIENTID,PATIENTNAME,ROOMID,ROOMTYPE)\
        VALUES(?,?,?,?)",(patientid,patientname,roomid,roomtype));

#PDETAILS
    print("\n Patient Details:")
    patientid=int(input("enter patient's id:"))
    patientname=input("enter patient's name:")
    age=int(input("enter the patient's age:"))
    gender=input("enter the gender:")
    address=input("enter the address of patient:")
    dateofadmission=int(input("enter date of admission:"))
    contactnumber=int(input("enter contact number:"))
    conn.execute("INSERT INTO PDETAILS(PATIENTID,PATIENTNAME,AGE,GENDER,ADDRESS,DATE,CONTACT)\
        VALUES(?,?,?,?,?,?,?)",(patientid,patientname,age,gender,address,dateofadmission,contactnumber));

#BDETAILS
    print("\n Billing Details:")
    billno=int(input("enter the bill num:"))
    generatedbilldate=int(input("enter generated bill date:"))
    patientid=int(input("enter patient's id:"))
    patientname=input("enter patient's name:")
    age=int(input("enter age"))
    admissiondate=int(input("enter admission date:"))
    dischargedate=int(input("enter discharge date:"))
    roomcharges=int(input("enter room charges:"))
    pathologyfees=int(input("enter pathology fees:"))
    doctorcheckupfees=int(input("enter doctor checkup fees"))
    miscellaneousfees=int(input("enter miscellaneous fees"))
    totalamount=roomcharges+pathologyfees+doctorcheckupfees+miscellaneousfees
    print("TOTAL=",totalamount)
    conn.execute("INSERT INTO BDETAILS(BILLNO,GENERATED,PATIENTID,PNAME,AGE,ADMISSIONDATE,DISCHARGEDATE,ROOM,PATHOLOGY,DOCTOR,MISCELLANEOUS,TOTAL)VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",(billno,generatedbilldate,patientid,patientname,age,admissiondate,dischargedate,roomcharges,pathologyfees,doctorcheckupfees,miscellaneousfees,totalamount));

#ADETAILS
    print("\n Appointment Details:")
    patientid=int(input("enter patient id:"))
    patientname=input("enter the name of patient:")
    doctorname=input("enter the name of doctor:")
    consultfees=input("enter the consult fees:")
    appointmentdate=input("enter the date of appointment:")
    appointmenttime=int(input("enter the appointementtime:"))
    timepreferred=int(input("enter the preferred time:"))
    appointmentnumber=int(input("enter the appointment number:"))
    paymentmode=input("enter the mode of payment:")
    conn.execute("INSERT INTO ADETAILS(PATIENTID,PATIENTNAME,DOCTORNAME,CONSULTFEES,APPOINTMENTDATE,APPOINTMENTTIME,TIMEPREFERRED,APPOINTMENT,PAYMENTMODE)VALUES(?,?,?,?,?,?,?,?,?)",(patientid,patientname,doctorname,consultfees,appointmentdate,appointmenttime,timepreferred,appointmentnumber,paymentmode));

#MDETAILS
    print("\n Medicine Details:")
    patientid=int(input("enter patient id:"))
    patientname=input("enter name of patient:")
    diseaseofpatient=input("enter name of disease:")
    medicinerecommended=input("enter name of medicine:")
    consulteddoctorname=input("enter name of recommended doctor:")
    conn.execute("INSERT INTO MDETAILS(PATIENTID,PATIENTNAME,DISEASEOFPATIENT,MEDICINERECOMMENDED,CONSULTEDDOCTORNAME)VALUES(?,?,?,?,?)",(patientid,patientname,diseaseofpatient,medicinerecommended,consulteddoctorname));
    conn.commit()

#this would display doctor details separately
def getDataDDetails():
    cursor=conn.execute("SELECT DNAME,ADDRESS,PHONE,QUALIFICATION,GENDER FROM DDETAILS")
    for row in cursor:
        print("DNAME=",row[0])
        print("ADDRESS=",row[1])
        print("PHONE=",row[2])
        print("QUALIFICATION=",row[3])       
        print("GENDER=",row[4],"\n")

#this would display patient's room details
def getDataRDetails():
    
    cursor=conn.execute("SELECT PATIENTID,PATIENTNAME, ROOMID,ROOMTYPE FROM RDETAILS")
    for row in cursor:
        print("PATIENTID=",row[0])
        print("PNAME=",row[1])
        print("ROOMID=",row[2])
        print("ROOMTYPE=",row[3],"\n")

#this would display patient details
def getDatsPDetails():
    
    cursor=conn.execute("SELECT PATIENTID,PATIENTNAME,AGE,GENDER,ADDRESS,DATE OFADMISSION,CONTACT NUMBER FROM PDETAILS")
    for row in cursor:
        print("PATIENTID=",row[0])
        print("PNAME=",row[1])
        print("AGE=",row[2])
        print("GENDER=",row[3])
        print("ADDRESS=",row[4])
        print("DATE OF ADMISSION=",row[5])
        print("CONTACT NUMBER=",row[6],"\n")

#this would display patient's billing details
def getDataBDetails():
    cursor=conn.execute("SELECT BILLNO,GENERATED,PATIENTID,PNAME,AGE,ADMISSIONDATE,DISCHARGEDATE,ROOM,PATHOLOGY,DOCTOR,MISCELLANEOUS,TOTAL FROM BDETAILS")
    for row in cursor:
        print("BILL NO=",row[0])
        print("GENERATED BILL DATE=",row[1])      
        print("PATIENT ID=",row[2])
        print("PNAME=",row[3])
        print("AGE=",row[4])
        print("DATE OF ADMISSION=",row[5])
        print("DATE OF DISCHARGE=",row[6])
        print("ROOM CHARGES=",row[7])
        print("PATHOLOGY FEES=",row[8])
        print("DOCTOR CHECKUP FEES=",row[9])
        print("MISCELLANEOUS FEES=",row[10])
        print("TOTAL AMOUNT OF BILL=",row[11],"\n")
       

#this would display patient's appointment details
def getDataADetails():
    
    cursor=conn.execute("SELECT PATIENTID, PATIENTNAME,DOCTORNAME,CONSULTFEES,APPOINTMENTDATE,APPOINTMENTTIME,TIMEPREFERRED,APPOINTMENT,PAYMENTMODE FROM ADETAILS")
    for row in cursor:
        print("PATIENTID=",row[0])
        print("PATIENTNAME=",row[1])
        print("DOCTORNAME=",row[2])
        print("CONSULTFEES=",row[3])
        print("APPOINTMENTDATE=",row[4])
        print("APPOINTMENTTIME=",row[5])
        print("TIMEPREFERRED=",row[6])
        print("APPOINTMENTNUMBER=",row[7])
        print("PAYMENTMODE=",row[8],"\n")

#this would display patient's medicine details
def getDataMDetails():
    
    cursor=conn.execute("SELECT PATIENTID,PATIENTNAME,DISEASEOFPATIENT,MEDICINERECOMMENDED,CONSULTEDDOCTORNAME FROM MDETAILS")
    for row in cursor:
        print("PATIENTID=",row[0])
        print("PATIENTNAME=",row[1])
        print("DISEASEOFPATIENT=",row[2])
        print("MEDICINERECOMMENDED=",row[3])
        print("CONSULTEDDOCTORNAME=",row[4],"\n")

#this would display all information about the patient
def getData():
    getDataDDetails()
    getDataRDetails()
    getDatsPDetails()
    getDataBDetails()
    getDataADetails()
    getDataMDetails()

#this would update patient's information
def UpdatePDetails():    
#PDETAILS
    print("\n Patient Details:")
    patientid=int(input("enter patient's id:"))
    patientname=input("enter patient's name:")
    age=int(input("enter the patient's age:"))
    gender=input("enter the gender:")
    address=input("enter the address of patient:")
    dateofadmission=int(input("enter date of admission:"))
    contactnumber=input("enter contact number:")

    conn.execute("UPDATE PDETAILS SET PATIENTNAME=?,AGE=?,GENDER=?,ADDRESS=?,DATE=?,CONTACT=? WHERE PATIENTID=?",(patientname,age,gender,address,dateofadmission,contactnumber,patientid))
    conn.commit()
    print("total number of rows updated:",conn.total_changes)

#this would update patient's doctor information
def UpdateDDetails():
#DDETAILS
    print("\n Doctor Details:")
    id=int(input("enter doctor's id:"))
    dname=input("enter the doctor's name:")
    address=input("enter the address:")
    phone=input("enter the phone number:")
    qualification=input("enter the qualification:")
    gender=input("enter gender:")

    conn.execute("UPDATE DDETAILS SET DNAME=?,ADDRESS=?,PHONE=?,QUALIFICATION=?,GENDER=? WHERE ID=?",(dname,address,phone,qualification,gender,id))
    conn.commit()
    print("total number of rows updated:",conn.total_changes)

#this would update patient's room details
def UpdateRDetails():
#RDETAILS
    print("\n Room Details:")
    patientid=int(input("enter patientid:"))
    patientname=input("enter patient name:") 
    roomid=int(input(" enter roomid number"))
    roomtype=input("enter roomtype[general/private]")

    conn.execute("UPDATE RDETAILS SET PATIENTNAME=?,ROOMID=?,ROOMTYPE=? WHERE PATIENTID=?",(patientname,roomid,roomtype,patientid))
    conn.commit()
    print("total number of rows updated:",conn.total_changes)

#this would update patient's billing details
def UpdateBDetails():
#BDETAILS
    print("\n Billing Details:")
    billno=int(input("enter the bill num:"))
    generatedbilldate=int(input("enter generated bill date:"))
    patientid=int(input("enter patient's id:"))
    patientname=input("enter patient's name:")
    age=int(input("enter age"))
    admissiondate=int(input("enter admission date:"))
    dischargedate=int(input("enter discharge date:"))
    roomcharges=int(input("enter room charges:"))
    pathologyfees=int(input("enter pathology fees:"))
    doctorcheckupfees=int(input("enter doctor checkup fees"))
    miscellaneousfees=int(input("enter miscellaneous fees"))
    totalamount=roomcharges+pathologyfees+doctorcheckupfees+miscellaneousfees
    print("TOTAL=",totalamount)

    conn.execute("UPDATE BDETAILS SET BILLNO=?,GENERATED=?,PNAME=?,AGE=?,ADMISSIONDATE=?,DISCHARGEDATE=?,ROOM=?,PATHOLOGY=?,DOCTOR=?,MISCELLANEOUS=?,TOTAL=? WHERE PATIENTID=?",(billno,generatedbilldate,patientname,age,admissiondate,dischargedate,roomcharges,pathologyfees,doctorcheckupfees,miscellaneousfees,totalamount,patientid))
    conn.commit()
    print("total number of rows updated:",conn.total_changes)

#this would update patient's appointment details
def UpdateADetails():
#ADETAILS
    print("\n Appointment Details:")
    patientid=int(input("enter patient id:"))
    patientname=input("enter the name of patient:")
    doctorname=input("enter the name of doctor:")
    consultfees=input("enter the consult fees:")
    appointmentdate=input("enter the date of appointment:")
    appointmenttime=int(input("enter the appointementtime:"))
    timepreferred=int(input("enter the preferred time:"))
    appointmentnumber=int(input("enter the appointment number:"))
    paymentmode=input("enter the mode of payment:")

    conn.execute("UPDATE ADETAILS SET PATIENTNAME=?,DOCTORNAME=?,CONSULTFEES=?,APPOINTMENTDATE=?,APPOINTMENTTIME=?,TIMEPREFERRED=?,APPOINTMENT=?,PAYMENTMODE=? WHERE PATIENTID=?",(patientname,doctorname,consultfees,appointmentdate,appointmenttime,timepreferred,appointmentnumber,paymentmode,patientid))
    conn.commit()
    print("total number of rows updated:",conn.total_changes)
#this would update patient's medicine details
def UpdateMDetails():
#MDETAILS
    print("\n Medicine Details:")
    patientid=int(input("enter patient id:"))
    patientname=input("\n enter name of patient:")
    diseaseofpatient=input("enter name of disease:")
    medicinerecommended=input("enter name of medicine:")
    consulteddoctorname=input("enter name of recommended doctor:")

    conn.execute("UPDATE MDETAILS SET PATIENTNAME=?,DISEASEOFPATIENT=?,MEDICINERECOMMENDED=?,CONSULTEDDOCTORNAME=? WHERE PATIENTID=?",(patientname,diseaseofpatient,medicinerecommended,consulteddoctorname,patientid))
    print("total number of rows updated:",conn.total_changes)
    conn.commit()
    print("total number of rows updated:",conn.total_changes)

#this would update all information
def UpdateData():
    UpdatePDetails()
    UpdateDDetails()
    UpdateRDetails()
    UpdateBDetails()
    UpdateADetails()
    UpdateMDetails()

def DeleteData():
    patientid=int(input("enter the patientid to be deleted:"))

    conn.execute("DELETE FROM DDETAILS WHERE ID=?",(patientid,))
    conn.execute("DELETE FROM RDETAILS WHERE PATIENTID=?",(patientid,))
    conn.execute("DELETE FROM PDETAILS WHERE PATIENTID=?",(patientid,))
    conn.execute("DELETE FROM BDETAILS WHERE PATIENTID=?",(patientid,))
    conn.execute("DELETE FROM ADETAILS WHERE PATIENTID=?",(patientid,))
    conn.execute("DELETE FROM MDETAILS WHERE PATIENTID=?",(patientid,))
    conn.commit()
    print("Total number of rows deleted:",conn.total_changes)

   
    
#this would search patient's information-ALL
def SearchPatientInfo():
    patientid=int(input("enter the patient id:"))
    cursor=conn.execute("SELECT PD.PATIENTID,PD.PATIENTNAME,PD.AGE,PD.GENDER,PD.ADDRESS,PD.DATE,PD.CONTACT,RD.ROOMID,RD.ROOMTYPE,\
        BD.BILLNO,BD.GENERATED,BD.ADMISSIONDATE,BD.DISCHARGEDATE,BD.ROOM,BD.PATHOLOGY,BD.DOCTOR,BD.MISCELLANEOUS,BD.TOTAL,\
        AD.DOCTORNAME,AD.CONSULTFEES,AD.APPOINTMENTDATE,AD.APPOINTMENTTIME,AD.TIMEPREFERRED,AD.APPOINTMENT,AD.PAYMENTMODE,\
        MD.DISEASEOFPATIENT,MD.MEDICINERECOMMENDED,MD.CONSULTEDDOCTORNAME\
        FROM PDETAILS AS PD,RDETAILS AS RD,BDETAILS AS BD,ADETAILS AS AD,MDETAILS AS MD\
        WHERE PD.PATIENTID=RD.PATIENTID=BD.PATIENTID=AD.PATIENTID=MD.PATIENTID AND PD.PATIENTID=?",(patientid,))

    for row in cursor:
        print("PATIENT DETAILS:")
        print("PATIENTID=",row[0])
        print("PNAME=",row[1])
        print("AGE=",row[2])
        print("GENDER=",row[3])
        print("ADDRESS=",row[4])
        print("DATE OF ADMISSION=",row[5])
        print("CONTACT NUMBER=",row[6],"\n")
        print("ROOM DETAILS:")
        print("ROOMID=",row[7])
        print("ROOMTYPE=",row[8],"\n")
        print("BILLING DETAILS:")
        print("BILL NO=",row[9])
        print("GENERATED BILL DATE=",row[10])
        print("DATE OF ADMISSION=",row[11])
        print("DATE OF DISCHARGE=",row[12])
        print("ROOM CHARGES=",row[13])
        print("PATHOLOGY FEES=",row[14])
        print("DOCTOR CHECKUP FEES=",row[15])
        print("MISCELLANEOUS FEES=",row[16])
        print("TOTAL AMOUNT OF BILL=",row[17],"\n")
        print("APPOINTMENT DETAILS:")
        print("DOCTORNAME=",row[18])
        print("CONSULTFEES=",row[19])
        print("APPOINTMENTDATE=",row[20])
        print("APPOINTMENTTIME=",row[21])
        print("TIMEPREFERRED=",row[22])
        print("APPOINTMENTNUMBER=",row[23])
        print("PAYMENTMODE=",row[24],"\n")
        print("MEDICINE DETAILS:")
        print("DISEASEOFPATIENT=",row[25])
        print("MEDICINERECOMMENDED=",row[26])
        print("CONSULTEDDOCTORNAME=",row[27],"\n")

#this would search only patient details
def SearchPDetails():
    patientid=int(input("enter the patient's id to know his/her details:"))
    cursor=conn.execute("SELECT PATIENTID,PATIENTNAME,AGE,GENDER,ADDRESS,DATE,CONTACT FROM PDETAILS\
                      WHERE PATIENTID=?",(patientid,))
    for row in cursor:
        print("PATIENT DETAILS:")
        print("PATIENTID=",row[0])
        print("PNAME=",row[1])
        print("AGE=",row[2])
        print("GENDER=",row[3])
        print("ADDRESS=",row[4])
        print("DATE OF ADMISSION=",row[5])
        print("CONTACT NUMBER=",row[6],"\n")

connectDatabase()
CreateTable()
while True:
    print("choose the options:\n1.New Record\n 2.view Individual Data-All")
    print("3.view All Data\n 4.Update Data\n")
    print("5.Search information\n 6.Search PatientDetails")
    print("7.delete data")
    print("8.exit")
    data=int(input())
    if data==8:
        break;
    elif data==1:
        NewRecord()
    elif data==2:
        while True:
            print("choose the options:\n 1.view Doctor Details\n 2.view Room Details\n 3.view patient details\n 4.view Bill Details\n 5.view Appointment Details\n 6.view Medicine Details\n 7.exit")
            data=int(input())
            if data==7:
                break;
            elif data==1:
                getDataDDetails()
            elif data==2:
                getDataRDetails()
            elif data==3:
                getDatsPDetails()
            elif data==4:
                getDataBDetails()
            elif data==5:
                getDataADetails()
            elif data==6:
                getDataMDetails()
            else:
                print("enter a valid option")
            
    elif data==3:
        getData()
        
    elif data==4:
        while True:
            print("choose options:\n 1.update individual records\n 2.update all data\n 3.exit")
            data=int(input())
            if data==3:
                break;
            elif data==1:
                while True:
                    print("choose options:\n 1.update patient details\n 2.update doctor details\n 3.update room details\n 4.update bill details\n 5.update appointment details\n 6.update medicine details\n 7.exit")
                    data=int(input())
                    if data==7:
                        break;
                    elif data==1:
                        UpdatePDetails()
                    elif data==2:
                        UpdateDDetails()
                    elif data==3:
                        UpdateRDetails()
                    elif data==4:
                        UpdateBDetails()
                    elif data==5:
                        UpdateADetails()
                    elif data==6:
                        UpdateMDetails()
                    else:
                        print("enter a valid option")
                 
            elif data==2:
                UpdateData()

    elif data==5:
        SearchPatientInfo()

    elif data==6:
        SearchPDetails()

    elif data==7:
        DeleteData()
        
    else:
        print("enter a valid option:")



CloseDatabase()
print("THANK YOU")
        
                 
 

  



